<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0" name="viewport" />
    <meta name="twitter:widgets:theme" content="light" />
    <meta property="og:title" content="Your-Title-Here" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="Your-Image-Url" />
    <meta property="og:description" content="Your-Page-Description" />
    <title>BINAR a Lighting Studio - Lighting Consultant</title>
    <link rel="shortcut icon" type="image/x-icon" href="/assets/img/logo/icon-warna.png" />

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700%7CLato:300,400,700" rel="stylesheet" type="text/css" />

    <!-- Css -->
    <link rel="stylesheet" href="/assets/css/core.min.css" />
    <link rel="stylesheet" href="/assets/css/skin.css" />
    @toastr_css

    <!--[if lt IE 9]>
      <script
        type="text/javascript"
        src="http://html5shiv.googlecode.com/svn/trunk/html5.js"
      ></script>
    <![endif]-->
</head>

<body class="shop home-page" style="overflow-x: hidden">

    <div class="wrapper reveal-side-navigation">
        <div class="wrapper-inner">
            <!-- Header -->
            <header class="header header-fixed header-fixed-on-mobile header-transparent" data-bkg-threshold="100" data-compact-threshold="100">
                <div class="header-inner">
                    <div class="row nav-bar">
                        <div class="column width-12 nav-bar-inner">
                            <div class="logo">
                                <div class="logo-inner">
                                    <a href="{{ url('/id/maintenance') }}"><img src="/assets/img/logo/logo_binar-white.png" alt="Binar Logo" /></a>
                                    <a href="{{ url('/id/maintenance') }}"><img src="/assets/img/logo/logo_binar-colour.png" alt="BINAR Logo" /></a>
                                </div>
                            </div>
                            <nav class="navigation nav-block secondary-navigation nav-right">
                                <ul>
                                    <li>
                                        <a href="#" class="contains-sub-menu"><span class="icon-language"></span> Bahasa</a>
                                        <ul class="sub-menu">
                                            <li class="@yield('nav-indonesian')">
                                                <a href="{{ url('/id/maintenance') }}">Bahasa Indonesia</a>
                                            </li>
                                            <li class="@yield('nav-english')">
                                                <a href="{{ url('/en/maintenance') }}">English</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </header>
            <!-- Header End -->

            @yield('container')

            <!-- Footer -->
            <footer class="footer">
                <div class="footer-bottom">
                    <div class="row">
                        <div class="column width-12">
                            <div class="footer-bottom-inner center">
                                <p class="copyright pull-left clear-float-on-mobile">
                                    &copy; BINAR A Lighting Studio. Hak Publikasi.
                                    <a href="{{ url('/id/maintenance') }}">Syarat dan Ketentuan</a> |
                                    <a href="{{ url('/id/maintenance') }}">Kebijakan Privasi</a>
                                </p>
                                <ul class="social-list list-horizontal pull-right clear-float-on-mobile">
                                    <li>
                                        <a href="https://www.facebook.com/binar.lighting"><span class="icon-facebook small"></span></a>
                                    </li>
                                    <li>
                                        <a href="https://www.youtube.com/watch?v=bIigCRnpIMU"><span class="icon-youtube small"></span></a>
                                    </li>
                                    <li>
                                        <a href="https://id.pinterest.com/binarlightingconsultant/"><span class="icon-pinterest small"></span></a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/binar_alightingstudio/"><span class="icon-instagram small"></span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer End -->
        </div>
    </div>

    <!-- Js -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js?v=3"></script>
    <script src="/assets/js/timber.master.min.js"></script>
    @toastr_js
    @toastr_render
</body>

</html>