@extends('en.layout.header-footer')
@section('nav-about_us', 'current')
@section('nav-our_philosophy', 'current')
@section('container')
<!-- Content -->
<div class="content clearfix">
  <!-- Full Width Slider Section -->
  <section class="section-block featured-media page-intro tm-slider-parallax-container">
    <div class="tm-slider-container full-width-slider" data-parallax data-parallax-fade-out data-animation="slide" data-scale-under="1140">
      <ul class="tms-slides">
        <li class="tms-slide" data-image data-as-bkg-image data-force-fit>
          <div class="tms-content">
            <div class="tms-content-inner left">
              <div class="row">
                <div class="column width-12">
                  <h1 class="tms-caption color-white inline" data-animate-in="preset:slideInUpShort;duration:1000ms;delay:100ms;" data-no-scale>
                    About BINAR
                  </h1>
                </div>
              </div>
            </div>
          </div>
          <img data-src="/assets/img/banner/about_us.jpg" data-retina src="images/blank.png" alt="" />
        </li>
      </ul>
    </div>
  </section>
  <!-- Full Width Slider Section -->

  <!-- Service Section -->
  <section class="section-block replicable-content bkg-blue-binar-body">
    <div class="row">
      <div class="column width-6">
        <h2 class="mb-50">Our Philosophy</h2>
        <p class="mb-50">
          The fundamental Philosophy of BINAR is taken from the meaning
          of word <i>BINAR</i> (in Bahasa), or a twinkle (in English),
          which means "emission of light". This combined with the
          character itself, which is flexible, does not require a
          propagation medium, can spread the colour spectrum when it
          passes through a prism, can reflect when it meets a mirror,
          can be formed, and can fill spaces and fields. BINAR is
          independent and can always develop and follow situations and
          conditions flexibly.
        </p>
      </div>
      <div class="column width-5 offset-1">
        <div class="row content-grid-2 flex">
          <img src="/assets/img/general/about-philosophy.jpg" width="760" height="500" alt="" />
        </div>
      </div>
    </div>
  </section>
  <!-- Service Section End -->

  <!-- Service Section -->
  <section class="section-block replicable-content bkg-blue-binar-body">
    <div class="row">
      <div class="column width-5">
        <img src="/assets/img/general/about-story.jpg" width="760" height="500" alt="" />
      </div>
      <div class="column width-6 offset-1">
        <div class="row content-grid-2 flex">
          <h2 class="mb-50">Our Story</h2>
          <p class="mb-100">
            Binar like a bowl of food, combining several people with
            different backgrounds and characteristics that complementing
            each other to create the right taste. Each person studied
            architectural lighting design because they were initially
            interested and continued to love the field. The deepening is
            achieved in different ways through formal informal
            education, which is always flowing and developing in line
            with the experience gained from each project taken.
          </p>
        </div>
      </div>
    </div>
  </section>
  <!-- Service Section End -->

  <!-- Hero 5 Section -->
  <div class="section-block hero-5 left show-media-column-on-mobile" style="background-color: #b36c01">
    <div class="media-column width-6 center horizon" data-animate-in="preset:slideInRightShort;duration:1000ms;delay:200ms;" data-threshold="0.6">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/bIigCRnpIMU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div class="row">
      <div class="column width-5 push-7">
        <div class="hero-content split-hero-content">
          <div class="hero-content-inner left">
            <h3 class="">BINAR A LIGHTING STUDIO</h3>
            <p class="lead mb-30">Lighting Consultant</p>
            <p>
              BINAR A Lighting Studio is an architectural lighting
              specialist that engage in exterior and facade, interior
              and landscape lighting. Our work is developed around
              aesthetics aspect with mainly tailored illumination design
              that fits well with the premises and the owner’s
              development aspiration.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Hero 5 Section End -->

  <!-- Team Grid -->
  <div class="section-block replicable-content team-2 bkg-blue-binar-body">
    <div class="row">
      <div class="column width-12">
        <h2 class="mb-50 center">Official Channels</h2>
      </div>
      <div class="column width-12">
        <div class="row content-grid-3">
          <div class="grid-item horizon" data-animate-in="preset:slideInUpShort;duration:1000ms;" data-threshold="0.3">
            <div class="thumbnail no-margin-bottom" data-hover-easing="easeInOut" data-hover-speed="500" data-hover-bkg-color="#ffffff" data-hover-bkg-opacity="0.9">
              <img src="images/team/team-member-1.jpg" width="760" height="500" alt="" />
            </div>
            <div class="team-content-info">
              <h4 class="mb-5">Facebook</h4>
              <h4 class="occupation" style="text-transform: capitalize">
                <span class="icon-facebook"></span>
                binar a lighting studio
              </h4>
              <a href="#" class="button bkg-blue-binar color-blue-binar color-hover-blue-binar mb-mobile-40">Facebook</a>
            </div>
          </div>
          <div class="grid-item horizon" data-animate-in="preset:slideInUpShort;duration:1000ms;delay:300ms;" data-threshold="0.3">
            <div class="thumbnail no-margin-bottom" data-hover-easing="easeInOut" data-hover-speed="500" data-hover-bkg-color="#ffffff" data-hover-bkg-opacity="0.9">
              <img src="images/team/team-member-3.jpg" width="760" height="500" alt="" />
            </div>
            <div class="team-content-info">
              <h4 class="mb-5">Instagram</h4>
              <h4 class="occupation" style="text-transform: lowercase">
                <span class="icon-instagram"></span>
                binar_alightingstudio
              </h4>
              <a href="#" class="button bkg-blue-binar color-blue-binar color-hover-blue-binar mb-mobile-40">Instagram</a>
            </div>
          </div>
          <div class="grid-item horizon" data-animate-in="preset:slideInUpShort;duration:1000ms;delay:600ms;" data-threshold="0.3">
            <div class="thumbnail no-margin-bottom" data-hover-easing="easeInOut" data-hover-speed="500" data-hover-bkg-color="#ffffff" data-hover-bkg-opacity="0.9">
              <img src="images/team/team-member-4.jpg" width="760" height="500" alt="" />
            </div>
            <div class="team-content-info">
              <h4 class="mb-5">Pinterest</h4>
              <h4 class="occupation" style="text-transform: capitalize">
                <span class="icon-pinterest"></span> Binar a Lighting
                Studio
              </h4>
              <a href="#" class="button bkg-blue-binar color-blue-binar color-hover-blue-binar mb-mobile-40">Pinterest</a>
            </div>
          </div>
          <div class="grid-item horizon" data-animate-in="preset:slideInUpShort;duration:1000ms;delay:600ms;" data-threshold="0.3">
            <div class="thumbnail no-margin-bottom" data-hover-easing="easeInOut" data-hover-speed="500" data-hover-bkg-color="#ffffff" data-hover-bkg-opacity="0.9">
              <img src="images/team/team-member-4.jpg" width="760" height="500" alt="" />
            </div>
            <div class="team-content-info">
              <h4 class="mb-5">Youtube</h4>
              <h4 class="occupation" style="text-transform: capitalize">
                <span class="icon-youtube"></span> Binar a Lighting
                Studio
              </h4>
              <a href="#" class="button bkg-blue-binar color-blue-binar color-hover-blue-binar mb-mobile-40">Youtube</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Team Grid End -->

  <!-- Testimonial Section 5 -->
  <div class="section-block testimonial-5 testimonials-5-about-1">
    <div id="testimonial-slider-1" class="testimonial-slider tm-slider-container">
      <ul class="tms-slides">
        <li class="tms-slide" data-image>
          <div class="tms-content-scalable">
            <div class="row">
              <div class="column width-12">
                <blockquote class="center large">
                  <p>
                    Incredible work! Best creative experience ever;
                    timely, well executed and one hell of the result.
                    Would recommend Nietszche to anyone who is looking
                    to revamp their identity.
                    <cite>John K. Riley - Harvest Goods.</cite>
                  </p>
                </blockquote>
              </div>
            </div>
          </div>
        </li>
        <li class="tms-slide" data-image>
          <div class="tms-content-scalable">
            <div class="row">
              <div class="column width-12">
                <blockquote class="center large">
                  <p>
                    A five star agency without doubt. Hire them!
                    <cite>John A. Adams - Repetition</cite>
                  </p>
                </blockquote>
              </div>
            </div>
          </div>
        </li>
        <li class="tms-slide" data-image>
          <div class="tms-content-scalable">
            <div class="row">
              <div class="column width-12">
                <blockquote class="center large">
                  <p>
                    Creativity redefined. These guys offer a unique
                    approach to every aspect<br />
                    of design and the result is simply stunning.
                    <cite>Jane Lariken - MUD Clothing.</cite>
                  </p>
                </blockquote>
              </div>
            </div>
          </div>
        </li>
        <li class="tms-slide" data-image>
          <div class="tms-content-scalable">
            <div class="row">
              <div class="column width-12">
                <blockquote class="center large">
                  <p>
                    Design, design and redesign is their motto. Sartre
                    won't stop until they have<br />
                    the perfect match between functionality and
                    esthetic.
                    <cite>Jack Tromso - Orcha Co.</cite>
                  </p>
                </blockquote>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
  <!-- Testimonial Section 5 End -->
</div>
<!-- Content End -->
@endsection