<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('en.homepage');
// });

// Route::get('/career/drafter', function () {
//     return view('en.recruitment-drafter');
// });

// Route::get('/career/junior_architect', function () {
//     return view('en.recruitment-junior_arch');
// });

// Route::get('/about_us/our_philosophy_story', function () {
//     return view('en.about-us');
// });

// Route::get('/projects', function () {
//     return view('en.projects');
// });

// Route::get('/services/our_service', function () {
//     return view('en.our-service');
// });

// Route::get('/lighting101', function () {
//     return view('en.lighting-101');
// });

// Route::get('/projects/noaa_social_dining', function () {
//     return view('en.projects.noaa_social_dining');
// });

Route::get('/en/maintenance', function () {
    return view('en.page.maintenance');
});

Route::get('/id/maintenance', function () {
    return view('id.page.maintenance');
});

// Page Terms-Condition
Route::get('/id/terms-condition', function () {
    return view('id.page.terms-condition');
});

Route::get('/en/terms-condition', function () {
    return view('en.page.terms-condition');
});

// Page Privacy-Policy
Route::get('/id/privacy-policy', function () {
    return view('id.page.privacy-policy');
});

Route::get('/en/privacy-policy', function () {
    return view('en.page.privacy-policy');
});

Route::post('/en/subscribe', 'Contact@sendMail');
