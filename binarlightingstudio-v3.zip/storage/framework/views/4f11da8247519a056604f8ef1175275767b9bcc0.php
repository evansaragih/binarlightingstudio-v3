<?php $__env->startSection('translate'); ?>
<nav class="navigation nav-block secondary-navigation nav-right">
    <ul>
        <li>
            <a href="#" class="contains-sub-menu"><span class="icon-language"></span> Language</a>
            <ul class="sub-menu">
                <li class="<?php echo $__env->yieldContent('nav-indonesian'); ?>">
                    <a href="<?php echo e(url('/id/terms-condition')); ?>">Bahasa Indonesia</a>
                </li>
                <li class="<?php echo $__env->yieldContent('nav-english'); ?>">
                    <a href="<?php echo e(url('/en/terms-condition')); ?>">English</a>
                </li>
            </ul>
        </li>
    </ul>
</nav>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('en.layout.maintenance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\binarlightingstudio-v3\resources\views/en/layout/terms-condition.blade.php ENDPATH**/ ?>