<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="<?php echo e(url('/assets/js/toastr/toastr.min.js')); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo e(url('/assets/css/toastr/toastr.min.css')); ?>">
<?php if(Session::has('status')): ?>
<script type="text/javascript">
    toastr.success('Data telah disimpan', 'Berhasil', {
        "positionClass": "toast-bottom-right",
        timeOut: 5000,
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut",
        "tapToDismiss": false

    });
</script>
<?php endif; ?> <?php if(Session::has('status_warning')): ?>

<script type="text/javascript">
    toastr.error('This Is error Message', 'Bottom Right', {
        "positionClass": "toast-bottom-right",
        timeOut: 5000,
        "closeButton": true,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut",
        "tapToDismiss": false

    });
</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\binarlightingstudio-v3\resources\views/en/layout/alert.blade.php ENDPATH**/ ?>