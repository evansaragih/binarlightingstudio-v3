<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0" name="viewport" />
    <meta name="twitter:widgets:theme" content="light" />
    <meta property="og:title" content="Your-Title-Here" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="Your-Image-Url" />
    <meta property="og:description" content="Your-Page-Description" />
    <title>BINAR a Lighting Studio - Lighting Consultant</title>
    <link rel="shortcut icon" type="image/x-icon" href="/assets/img/logo/icon-warna.png" />

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700%7CLato:300,400,700" rel="stylesheet" type="text/css" />

    <!-- Css -->
    <link rel="stylesheet" href="/assets/css/core.min.css" />
    <link rel="stylesheet" href="/assets/css/skin.css" />

    <!--[if lt IE 9]>
      <script
        type="text/javascript"
        src="http://html5shiv.googlecode.com/svn/trunk/html5.js"
      ></script>
    <![endif]-->
</head>

<body class="shop home-page" style="overflow-x: hidden">
    <!-- Side Navigation Menu -->
    <aside class="side-navigation-wrapper enter-right" data-no-scrollbar data-animation="scale-in">
        <div class="side-navigation-scroll-pane">
            <div class="side-navigation-inner">
                <div class="side-navigation-header">
                    <div class="navigation-hide side-nav-hide">
                        <a href="#">
                            <span class="icon-cancel medium"></span>
                        </a>
                    </div>
                </div>
                <nav class="side-navigation">
                    <ul>
                        <li class="current">
                            <a href="#" class="contains-sub-menu">Home</a>
                        </li>
                        <li>
                            <a href="#" class="contains-sub-menu">Careers</a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="about-style-one.html">Drafter</a>
                                </li>
                                <li>
                                    <a href="about-style-two.html">Junior Architect (Internship)</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="contains-sub-menu">About Us</a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="about-style-one.html">Our Philosophy & Story</a>
                                </li>
                                <li>
                                    <a href="about-style-two.html">Our Studio</a>
                                </li>
                                <li>
                                    <a href="about-style-three.html">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="about-style-three.html">Terms & Conditions</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="contains-sub-menu">Projects</a>
                        </li>
                        <li>
                            <a href="#" class="contains-sub-menu">Services</a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="elements-accordions.html">Our Service</a>
                                </li>
                                <li>
                                    <a href="elements-buttons.html">Work Together</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#" class="contains-sub-menu">Lighting 101</a>
                        </li>
                    </ul>
                </nav>
                <div class="side-navigation-footer">
                    <p class="copyright no-margin-bottom">
                        &copy; 2021 BINAR A Lighting Studio.
                    </p>
                </div>
            </div>
        </div>
    </aside>
    <!-- Side Navigation Menu End -->

    <div class="wrapper reveal-side-navigation">
        <div class="wrapper-inner">
            <!-- Header -->
            <header class="header header-fixed header-fixed-on-mobile header-transparent" data-bkg-threshold="100" data-compact-threshold="100">
                <div class="header-inner">
                    <div class="row nav-bar">
                        <div class="column width-12 nav-bar-inner">
                            <div class="logo">
                                <div class="logo-inner">
                                    <a href="index.html"><img src="/assets/img/logo/logo_binar-white.png" alt="Binar Logo" /></a>
                                    <a href="index.html"><img src="/assets/img/logo/logo_binar-colour.png" alt="BINAR Logo" /></a>
                                </div>
                            </div>
                            <nav class="navigation nav-block secondary-navigation nav-right">
                                <ul>
                                    <li>
                                        <!-- Dropdown Cart Overview -->
                                        <div class="dropdown">
                                            <a href="#" class="nav-icon cart button no-page-fade"><span class="cart-indication"><span class="icon-bell"></span>
                                                    <span class="badge">1</span></span></a>
                                            <ul class="dropdown-list custom-content cart-overview">
                                                <li class="cart-item">
                                                    <a href="single-product.html" class="product-thumbnail">
                                                        <img src="images/shop/cart/cart-thumb-small.jpg" alt="" />
                                                    </a>
                                                    <div class="product-details">
                                                        <a href="single-product.html" class="product-title">
                                                            Check Our New Instagram Post
                                                        </a>
                                                        <span class="product-quantity">2 x</span>
                                                        <span class="product-price"><span class="currency">$</span>15.00</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="aux-navigation hide">
                                        <!-- Aux Navigation -->
                                        <a href="#" class="navigation-show side-nav-show nav-icon">
                                            <span class="icon-menu"></span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                            <nav class="navigation nav-block primary-navigation nav-right">
                                <ul>
                                    <li class="current">
                                        <a href="blog.html">Home</a>
                                    </li>
                                    <li>
                                        <a href="blog.html">Careers</a>
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="blog.html">Drafter</a>
                                            </li>
                                            <li>
                                                <a href="blog-four-columns-full-width.html">Junior Architect (Internship)</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="blog.html">About Us</a>
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="blog.html">Our Philosophy & Story</a>
                                            </li>
                                            <li>
                                                <a href="blog-four-columns-full-width.html">Our Studio</a>
                                            </li>
                                            <li>
                                                <a href="blog-sidebar-right-with-media.html">Privacy Policy</a>
                                            </li>
                                            <li>
                                                <a href="blog-sidebar-right-with-media.html">Terms & Conditions</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="blog.html">Projects</a>
                                    </li>
                                    <li>
                                        <a href="blog.html">Services</a>
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="blog.html">Our Services</a>
                                            </li>
                                            <li>
                                                <a href="blog-four-columns-full-width.html">Work Together</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a href="blog.html">Lighting 101</a>
                                    </li>
                                    <li>
                                        <a href="blog.html"><span class="icon-language"></span> Language</a>
                                        <ul class="sub-menu">
                                            <li>
                                                <a href="blog.html">Bahasa Indonesia</a>
                                            </li>
                                            <li>
                                                <a href="blog-four-columns-full-width.html">English</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </header>
            <!-- Header End -->

            <?php echo $__env->yieldContent('containers'); ?>

            <!-- Footer -->
            <footer class="footer">
                <div class="footer-top">
                    <div class="row flex">
                        <div class="column width-3">
                            <div class="widget">
                                <h4 class="widget-title weight-light">About Us</h4>
                                <a href="">Our Philosophy</a><br />
                                <a href="">Our Story</a><br />
                                <a href="">Official Channels</a><br />
                                <a href="">Our Studio</a><br />
                                <p></p>
                            </div>
                        </div>
                        <div class="column width-3">
                            <div class="widget">
                                <h4 class="widget-title weight-light">Projects</h4>
                                <a href="">Completed Project</a><br />
                                <a href="">On Going Project</a><br />
                                <p></p>
                            </div>
                        </div>
                        <div class="column width-3">
                            <div class="widget">
                                <h4 class="widget-title weight-light">Services</h4>
                                <a href="">Our Services</a><br />
                                <a href="">How We Works</a><br />
                                <a href="">Helps, Term & Condition</a><br />
                                <a href="">Privacy Policy</a><br />
                                <p></p>
                            </div>
                        </div>
                        <div class="column width-3">
                            <div class="widget">
                                <h4 class="widget-title weight-light">Languages</h4>
                                <a href="">Bahasa Indonesia</a><br />
                                <a href="">English</a><br />
                                <p></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    <div class="row">
                        <div class="column width-12">
                            <div class="footer-bottom-inner center">
                                <p class="copyright pull-left clear-float-on-mobile">
                                    &copy; BINAR A Lighting Studio. All Rights Reserved.
                                    <a href="#">Terms & Conditions</a> |
                                    <a href="#">Cookie policy</a>
                                </p>
                                <ul class="social-list list-horizontal pull-right clear-float-on-mobile">
                                    <li>
                                        <a href="#"><span class="icon-twitter small"></span></a>
                                    </li>
                                    <li>
                                        <a href="#"><span class="icon-facebook small"></span></a>
                                    </li>
                                    <li>
                                        <a href="#"><span class="icon-youtube small"></span></a>
                                    </li>
                                    <li>
                                        <a href="#"><span class="icon-vimeo small"></span></a>
                                    </li>
                                    <li>
                                        <a href="#"><span class="icon-instagram small"></span></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- Footer End -->
        </div>
    </div>

    <!-- Js -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js?v=3"></script>
    <script src="/assets/js/timber.master.min.js"></script>
</body>

</html><?php /**PATH C:\xampp\htdocs\binarlightingstudio-v3\resources\views/en/layout/header.blade.php ENDPATH**/ ?>